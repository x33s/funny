#!/usr/bin/env node
/**
 * generate.js —— 分年级汉字表 → chars.js
 *
 * 用法：
 *   1) npm install pinyin-pro
 *   2) node generate.js
 *
 * 输出：
 *   chars.js      —— 给 index.html / learn.html 直接用
 *   chars.json    —— 纯 JSON，方便其他程序读取
 *   report.txt    —— 统计报告（各年级字数、多音字、无拼音字）
 *
 * 可选：
 *   words.extra.json —— 覆盖任意字的组词/例句/拼音/图标
 *   格式：{ "天": { "w": "天空", "s": "天空蓝蓝的。", "p": "tiān", "icon": "🌤️" } }
 */

'use strict';

const fs = require('fs');

/* ================= 依赖检查 ================= */
let pinyinLib;
try {
  pinyinLib = require('pinyin-pro');
} catch (err) {
  console.error('\n[缺少依赖] 请先在项目目录运行：\n  npm install pinyin-pro\n');
  process.exit(1);
}

/* ================= 配置 ================= */
const CONFIG = {
  MAX_CHARS: 1800,      // 最多生成多少个不重复汉字
  DEDUPE: true,         // 全局去重
  STAGE_BY: 'id',       // 'id'：按 1-200/201-600/601-1800 切三段（贴洪恩）
                        // 'grade'：1-2 年级 / 3-4 年级 / 5-6 年级 三段
  OUT_JS: 'chars.js',
  OUT_JSON: 'chars.json',
  OUT_REPORT: 'report.txt',
  EXTRA_FILE: 'words.extra.json',
};

/* ================= 分年级字表 =================
 * 说明：下面是按年级整理的常用识字字表，总量约 1700 字。
 * 如果你要严格对齐统编版教材，把每一段替换成对应册次的识字表即可。
 * 空格、标点会被自动过滤，重复字会自动去重。
 * ============================================== */
const RAW = {
  1: `
    天地人你我他一二三四五六七八九十上下口耳目手足站坐日月水火山石田禾
    对云雨风花鸟虫爸妈棋鸡马土不字词语句子画打桌纸文数学音乐妹奶白皮
    小桥台雪儿草家是车羊走也秋气了树叶片大飞会个的船两头在里看见闪星
    江南可采莲东西北尖说春青蛙夏弯地冬男女开关正反远有色近听无声去还
    来多少黄牛只猫边鸭苹果杏桃书包尺作业本笔刀课早校明力尘从众双木林
    森条心升国旗中红歌起么美丽立午晚昨今年影前后黑狗左右它好朋友比尾
    巴谁长短把伞兔最公写诗点要过给当别到没海真分空话朵和汽水沙发菜爱
    吃玩球跳高兴老师同学笑这那样快些习每天好姐弟哥叔姨爷姥外公婆伯婶
    舅姑娘阿宝贝娃幼儿童少年青春季节年月日时分秒早晚午夜钟点刻半整差
    第初末底头尾中间旁边左右前后里外上下东西南北
  `,
  2: `
    塘脑袋灰哇教捕迎阿姨龟披鼓晒极傍越滴溪奔洋坏淹没冲毁屋猜植如为
    旅备纷刺底炸离识粗得滩艘军舰帆稻园孔翠队铜号梧桐掌枫松柏装桦耐守
    疆银杉化桂莺拂堤柳醉咏妆丝绦裁剪脱袄寻羞姑遮掩探嫩符解触杜鹃邮递
    裹寄局堆破漏懊丧啊猬绚籽礼邓坛龄格握致勃挖选茁移挥填扶亭咨询剧管
    理宝塔餐厅曾蒙泞顺踏荆棘瓣莹觅需献卫兵突枪抢敌指挥员冲锋阵坚守退
    败胜攻守打踢投接传带穿脱戴洗擦扫倒烧煮蒸炒炸烤冻藏露盖遮挡拦阻救
    护帮助团结合作分享争和谅解容忍耐坚持努力勤奋懒惰聪明笨巧灵活呆板
    细心粗心认真马虎诚实谎骗偷抢赔贷存取花省赚亏贵贱富穷
  `,
  3: `
    坝汉艳扮扬读摔跤凤洁荒笛罚假臂裳径斜赠刘残君橙挑铺泥晶紧列凌增棕
    钥匙缤纷邮爽喇叭勾梨频抖振韵掠吟辽阔呢喃眯喵孵叽偶尔伐斧锯切煤燃
    柴咱偷答鸳鸯惠崇豚梅伶俐漾倦闲散纤杆痕挨蓬胀翩蹈录凡距款绸膜瞎益
    约斑援掷捞缚络缭资贡贷陶罐骄谦虚懦恼怒代价匀称皱配撒扯狮豹盼积累
    遂城乡村镇街道路桥河湖海江溪泉井池塘山岭峰谷洞岩石林森竹花草叶根
    枝干皮果种苗稻麦米豆瓜菜肉鱼蛋奶茶水酒油盐糖醋药衣服裤鞋袜帽巾被
    床桌椅柜灯窗墙地板门锁包箱袋篮盒瓶罐杯碗盘筷勺锅刀叉伞扇钟表镜梳
    刷毛巾
  `,
  4: `
    盐薄屹昂鼎沸贯浩崩震霎余恢鹅卵俗跃穗镀埂烁巢苇罗霸占昧坠怀豌僵预
    揭苔囚框溢蝙蝠即锐系铛蝇证障碍荧屏唤纪获赖潜亿索奥舶质哲避撼喧雀
    檐杂稀篱蜻蜓蝶宿徐疏茅翁剥构芍冠朴素率附捣谐绮谈慰藉卜瞥琥珀嗡脂
    拭渗俯扎澎湃钝仅绘隧衍颅膨捷辟崭乒乓拥臭蔬菜碳癌症疾灶漫涛军队士
    兵将来将军战队战场战斗胜利失败进攻防守保卫国家人民生活幸福快乐健
    康平安安全危险紧急情况处理办法解决问题
  `,
  5: `
    鹭嫌嵌匣嗜亩播吩咐慕矮懂兰箩婆幽享陪趴眸咂召臣议缺宫献诺抄罪怯拒
    荆隼瀚鸵赢侵略垒丘岔碾惑酬誓谎延悔郎爹嫂恳筛歹罕狱酿瞌拘偎衰泰仞
    岳摩遗涕巫洛肆礴吨镌晦旖旎垠峨鄂缀篙棹妒忌曹督幔私寨擂呐弩丞踉跄
    泊冈饥碟俺杖擒芝迸涧獐猕猴耶挈瞑窍楷秽轧弦揿搔窈窕纽扣憎科学实验
    观察记录测量计算数据结果分析研究发现问题提出假设验证结论交流讨论
    合作探究创新实践操作技能方法步骤过程
  `,
  6: `
    邀俯瀑峭躯津蕴侠谧巷俏逗庞烘烤勤勉吻施挠庸艰毅铲劣惹讥浆挚寝频朦
    胧凄斑篇搁填怨掀唉裹魁梧淋撕霉虑悠仪歉溜嘿割晶蔼资矿赐竭挪蒸秧萎
    番锻雅旬熬蒜醋饺翡拌榛栗筝鞭麦寺逛籍屉怖瞅魔胖刑哼峻残匪窝啃舅鸿
    旺炊乖裙兜币橱锈揉玛蘸毒撇噎搓喳吭娜伊搅埃伦文学艺术音乐绘画书法
    舞蹈戏剧电影诗歌散文小说故事寓言童话神话传说历史地理科学物理化学
    生物政治经济法律道德
  `,
};

/* ================= 补足字池 =================
 * 如果上面分年级字表去重后不足 MAX_CHARS，
 * 从这里按顺序补入，grade 记为 6。
 * ============================================ */
const FALLBACK = `
爱安白百班般板办半帮包宝保报抱北备背被本比笔必毕边变便标表别宾冰病
并玻播伯驳博补布步部才材财采彩菜参残仓藏操草册侧层查茶察差拆产常长
厂场唱抄超朝潮车彻尘沉陈称城成承程吃池迟持尺齿冲虫抽丑臭出除础处触
川穿传船窗床创吹春词此次从粗村存寸错答达打大代带待袋单但担当党刀导
岛到倒道得的灯等低地弟第点典电店垫殿调掉爹跌叠丁顶定东冬懂动都豆读
独度短段断队对吨多朵额恶儿耳二发法帆翻凡反饭方房防访放飞非肥费分份
风封疯峰锋夫服福府父付负妇附复富该改盖干甘赶敢感刚钢高告哥歌格个各
给根跟更工公功攻供共狗构够姑古谷股故顾瓜挂怪关观官管惯光广规贵国果
过哈孩海害含寒喊汉汗行好号浩喝合何河和黑很红后厚候呼胡湖虎互户护花
华画话坏欢还环换黄回会婚活火或货机鸡积基几己挤计记纪技际济继加家甲
价架尖坚间肩检简见件建健将江讲降交角脚叫教接街节结解姐介借今金仅紧
进近尽京经惊精井景静境究九久酒旧就居局举句具剧据卷决绝军咖卡开看康
考靠科可克刻客课肯空口哭苦块快宽款况亏困拉啦来蓝览烂劳老乐雷泪类冷
离李里理力立丽利例连联脸练良凉两亮量了料列林临灵领另令留流六龙楼路
录旅绿乱论罗落妈麻马码吗买麦卖满慢忙猫毛么没每美妹门们猛梦米面苗民
明命摸模木目拿哪那奶男南难脑闹呢内能你年念娘鸟您牛农弄女暖哦欧怕排
牌派盘判旁胖跑泡陪朋批皮片票品平评苹瓶破普七妻期其奇骑起气汽器千前
钱浅强墙桥巧切亲琴轻清情请庆穷秋求球区取全权泉却群然让热人认任日容
肉如乳入软撒三色森杀沙山删闪善商上少绍蛇设社身深神审生声省圣师十石
时识实食史使始市事是适收手守首受书叔树数双水睡顺说思死四送速素算虽
随岁孙所他她它台太谈弹探汤唐堂躺讨特疼提题体天田条跳铁听停挺通同头
突图土团推腿外完玩晚万王往网忘危为围伟委卫未位味温文问我无五午武务
物西希息习洗喜系细下夏先鲜现线相想向像消小校笑些写谢心新信星行醒姓
幸休修需许序续选学雪寻训呀压牙亚烟言严研眼演验央羊阳样要药爷也业叶
夜一衣医依已以义艺议因音银引饮应英迎影用友有又右于鱼雨语育元员园原
远院愿约月云运杂再在咱脏早造怎增扎展站张章找照者这真正证只之知直职
止纸指至志制质治中终钟种众重周州主住注祝转装状准桌子字自总走足最左
作坐座
`;

/* ================= 高频字手工覆盖 =================
 * 这些字优先使用这里的组词/例句/图标；其余字用占位。
 * 想精修更多字，推荐写进 words.extra.json，不必改本文件。
 * ================================================ */
const WORD_OVERRIDES = {
  天: { w: '天空', s: '天空蓝蓝的。', icon: '🌤️' },
  地: { w: '大地', s: '大地绿了。', icon: '🌍' },
  人: { w: '大人', s: '一个大人。', icon: '🧑' },
  你: { w: '你好', s: '你好，朋友！', icon: '👉' },
  我: { w: '我们', s: '我们是朋友。', icon: '🙋' },
  他: { w: '他们', s: '他们一起玩。', icon: '👦' },
  一: { w: '一个', s: '一个人。', icon: '1️⃣' },
  二: { w: '二月', s: '二月来了。', icon: '2️⃣' },
  三: { w: '三天', s: '过了三天。', icon: '3️⃣' },
  四: { w: '四月', s: '四月花开。', icon: '4️⃣' },
  五: { w: '五个', s: '五个苹果。', icon: '5️⃣' },
  六: { w: '六月', s: '六月很热。', icon: '6️⃣' },
  七: { w: '七天', s: '一星期七天。', icon: '7️⃣' },
  八: { w: '八只', s: '八只小鸟。', icon: '8️⃣' },
  九: { w: '九月', s: '九月开学。', icon: '9️⃣' },
  十: { w: '十个', s: '十个手指。', icon: '🔟' },
  上: { w: '山上', s: '山上有树。', icon: '⬆️' },
  下: { w: '下山', s: '他们下山了。', icon: '⬇️' },
  口: { w: '门口', s: '他在门口。', icon: '👄' },
  耳: { w: '耳朵', s: '耳朵听声音。', icon: '👂' },
  目: { w: '目光', s: '目光亮亮的。', icon: '👁️' },
  手: { w: '小手', s: '小手洗干净。', icon: '✋' },
  足: { w: '足球', s: '他踢足球。', icon: '🦶' },
  日: { w: '日出', s: '日出了。', icon: '☀️' },
  月: { w: '月亮', s: '月亮弯弯的。', icon: '🌙' },
  水: { w: '喝水', s: '多喝水。', icon: '💧' },
  火: { w: '火车', s: '火车开来了。', icon: '🔥' },
  山: { w: '大山', s: '一座大山。', icon: '⛰️' },
  石: { w: '石头', s: '捡石头。', icon: '🪨' },
  田: { w: '田地', s: '田里有禾苗。', icon: '🌾' },
  土: { w: '泥土', s: '泥土软软的。', icon: '🟫' },
  雨: { w: '下雨', s: '下雨了。', icon: '🌧️' },
  风: { w: '大风', s: '风好大。', icon: '💨' },
  花: { w: '花朵', s: '花朵开了。', icon: '🌸' },
  草: { w: '小草', s: '小草绿了。', icon: '🌱' },
  树: { w: '大树', s: '大树很高。', icon: '🌳' },
  鸟: { w: '小鸟', s: '小鸟唱歌。', icon: '🐦' },
  鱼: { w: '小鱼', s: '小鱼游水。', icon: '🐟' },
  虫: { w: '虫子', s: '一只小虫。', icon: '🐛' },
  车: { w: '小车', s: '一辆小车。', icon: '🚗' },
  门: { w: '大门', s: '大门开了。', icon: '🚪' },
  牛: { w: '小牛', s: '小牛吃草。', icon: '🐂' },
  羊: { w: '小羊', s: '小羊咩咩叫。', icon: '🐑' },
  猫: { w: '小猫', s: '小猫睡觉。', icon: '🐱' },
  狗: { w: '小狗', s: '小狗跑得快。', icon: '🐶' },
  鸡: { w: '公鸡', s: '公鸡打鸣。', icon: '🐔' },
  鸭: { w: '鸭子', s: '鸭子游泳。', icon: '🦆' },
  爸: { w: '爸爸', s: '爸爸回来了。', icon: '👨' },
  妈: { w: '妈妈', s: '妈妈抱我。', icon: '👩' },
  家: { w: '回家', s: '回家吃饭。', icon: '🏠' },
  雪: { w: '下雪', s: '下雪了。', icon: '❄️' },
  云: { w: '白云', s: '白云飘走了。', icon: '☁️' },
};

/* ================= 工具函数 ================= */
const cleanText = (str) => str.replace(/[^\u4e00-\u9fa5]/g, '');

function getPinyin(ch) {
  try {
    const arr = pinyinLib.pinyin(ch, { toneType: 'symbol', type: 'array' });
    return arr && arr[0] ? arr[0] : '';
  } catch {
    return '';
  }
}

function isPolyphonic(ch) {
  try {
    const all = pinyinLib.pinyin(ch, { multiple: true, type: 'array' });
    return Array.isArray(all) && all.length > 1;
  } catch {
    return false;
  }
}

function stageOf(grade, id) {
  if (CONFIG.STAGE_BY === 'grade') {
    if (grade <= 2) return 1;
    if (grade <= 4) return 2;
    return 3;
  }
  // 默认：按 id 切 1-200 / 201-600 / 601-1800
  if (id <= 200) return 1;
  if (id <= 600) return 2;
  return 3;
}

/* ================= 读取 extra 覆盖 ================= */
let EXTRA = {};
if (fs.existsSync(CONFIG.EXTRA_FILE)) {
  try {
    EXTRA = JSON.parse(fs.readFileSync(CONFIG.EXTRA_FILE, 'utf8'));
    console.log(`已读取 ${CONFIG.EXTRA_FILE}，覆盖 ${Object.keys(EXTRA).length} 个字`);
  } catch (err) {
    console.warn(`[警告] ${CONFIG.EXTRA_FILE} 解析失败，已忽略：${err.message}`);
  }
}

/* ================= 构建字表 ================= */
function buildList() {
  const list = [];
  const seen = new Set();
  const gradeStats = {};
  let dropped = 0;
  let fallbackUsed = 0;

  const push = (ch, grade) => {
    if (list.length >= CONFIG.MAX_CHARS) return false;
    if (CONFIG.DEDUPE && seen.has(ch)) {
      dropped++;
      return true;
    }
    seen.add(ch);
    list.push({ h: ch, grade });
    return true;
  };

  // 1. 按年级顺序
  const grades = Object.keys(RAW).map(Number).sort((a, b) => a - b);
  for (const grade of grades) {
    const chars = cleanText(RAW[grade]);
    gradeStats[grade] = { raw: chars.length, kept: 0 };
    for (const ch of chars) {
      if (list.length >= CONFIG.MAX_CHARS) break;
      const before = list.length;
      push(ch, grade);
      if (list.length > before) gradeStats[grade].kept++;
    }
    if (list.length >= CONFIG.MAX_CHARS) break;
  }

  // 2. 不足则从补足池补
  if (list.length < CONFIG.MAX_CHARS) {
    for (const ch of cleanText(FALLBACK)) {
      if (list.length >= CONFIG.MAX_CHARS) break;
      const before = list.length;
      push(ch, 6);
      if (list.length > before) fallbackUsed++;
    }
  }

  return { list, gradeStats, dropped, fallbackUsed };
}

/* ================= 生成条目 ================= */
function enrich(item, id) {
  const ch = item.h;
  const extra = EXTRA[ch] || {};
  const ov = WORD_OVERRIDES[ch] || {};

  const p = extra.p || getPinyin(ch);
  const w = extra.w || ov.w || '';
  const s = extra.s || ov.s || `这是“${ch}”字。`;
  const icon = extra.icon || ov.icon || '';

  return {
    id,
    h: ch,
    p,
    w,
    s,
    stage: stageOf(item.grade, id),
    grade: item.grade,
    icon,
  };
}

/* ================= 输出 ================= */
function writeJS(items) {
  const lines = items.map(it => '  ' + JSON.stringify(it)).join(',\n');
  const content =
    '/* 自动生成，请勿手动修改。生成脚本：generate.js */\n' +
    'window.CHARS = [\n' + lines + '\n];\n';
  fs.writeFileSync(CONFIG.OUT_JS, content, 'utf8');
}

function writeReport({ items, gradeStats, dropped, fallbackUsed, noPinyin, polyphonic, noWord }) {
  const lines = [];
  lines.push('=== 生成报告 ===');
  lines.push(`生成时间：${new Date().toLocaleString()}`);
  lines.push(`目标字数：${CONFIG.MAX_CHARS}`);
  lines.push(`实际生成：${items.length}`);
  lines.push(`去重丢弃：${dropped}`);
  lines.push(`补足池补入：${fallbackUsed}`);
  lines.push('');
  lines.push('各年级字数：');
  Object.keys(gradeStats).sort().forEach(g => {
    const s = gradeStats[g];
    lines.push(`  ${g} 年级：保留 ${s.kept} / 原始 ${s.raw}`);
  });
  lines.push('');
  lines.push(`未配置组词的字：${noWord.length}`);
  lines.push(`  前 80 个：${noWord.slice(0, 80).join(' ')}`);
  lines.push('');
  if (noPinyin.length) {
    lines.push(`无拼音的字（${noPinyin.length}）：${noPinyin.join(' ')}`);
    lines.push('');
  }
  if (polyphonic.length) {
    lines.push(`多音字（${polyphonic.length}）：${polyphonic.join(' ')}`);
    lines.push('  → 已取默认常用读音；如需指定，在 words.extra.json 里写 "p" 字段覆盖。');
  }
  fs.writeFileSync(CONFIG.OUT_REPORT, lines.join('\n'), 'utf8');
}

/* ================= 主流程 ================= */
function main() {
  const { list, gradeStats, dropped, fallbackUsed } = buildList();

  const noPinyin = [];
  const polyphonic = [];
  const noWord = [];

  const items = list.map((it, idx) => {
    const id = idx + 1;
    if (isPolyphonic(it.h)) polyphonic.push(it.h);
    const obj = enrich(it, id);
    if (!obj.p) noPinyin.push(it.h);
    if (!obj.w) noWord.push(it.h);
    return obj;
  });

  writeJS(items);
  fs.writeFileSync(CONFIG.OUT_JSON, JSON.stringify(items, null, 2), 'utf8');
  writeReport({ items, gradeStats, dropped, fallbackUsed, noPinyin, polyphonic, noWord });

  console.log('');
  console.log(`✅ 已生成 ${items.length} 个字`);
  console.log(`   ${CONFIG.OUT_JS}`);
  console.log(`   ${CONFIG.OUT_JSON}`);
  console.log(`   ${CONFIG.OUT_REPORT}`);
  console.log('');
  console.log('各年级字数：');
  Object.keys(gradeStats).sort().forEach(g => {
    console.log(`   ${g} 年级：${gradeStats[g].kept}`);
  });
  if (fallbackUsed) console.log(`   补足池：${fallbackUsed}`);
  if (noPinyin.length) console.log(`\n⚠️ ${noPinyin.length} 个字没有拼音，详见 report.txt`);
  if (polyphonic.length) console.log(`ℹ️ ${polyphonic.length} 个多音字，已取默认读音，详见 report.txt`);
}

main();